import { createSlice } from '@reduxjs/toolkit'

const initialState = {
    toggle: false,
    user: "" || null

}

const ReduxState = createSlice({
  name: "reduxState",
  initialState,
  reducers: {
    changeToggle: (state, {payload}) =>{
        state.toggle = payload
    },

    loginUser: (state, {payload}) =>{
        state.user = payload
    },
    
    logOut: (state) =>{
        state.user = null
    }
  }
});

export const {changeToggle, loginUser, logOut} = ReduxState.actions

export default ReduxState.reducer