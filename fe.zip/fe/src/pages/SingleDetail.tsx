
const SingleDetail = () => {
  return (
    <div>
        <div className="grid grid-cols-1 md:grid-cols-5">
        <div className="col-span-1 md:col-span-2 bg-purple-600">
            <img className="w-full h-[500px]" />
        </div>
        <div className="col-span-3 bg-purple-200 md:col-span-3 ml:4 flex flex-col">
            <div className="mb-6 text-[30px] font-bold">Title</div>
            <div>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolor corrupti cupiditate eos molestiae culpa eligendi reprehenderit repudiandae voluptates earum quod.
            </div>
            <div className="mt-5 text-[12px] flex">
                <div className="mr-5">
                    <strong className="font-[600]">3</strong> Likes
                </div>
                <div className="mr-5">
                    <strong className="font-[600]">3</strong> Review
                </div>
                <div className="flex-1"/>
                <div className="mr-5">
                    <strong className="font-[600]">3</strong> star rating
                </div>
            </div>

            <div className="mt-10 flex">
                <div className="py-2 px-8 rounded-sm bg-purple-600 text-white">Like</div>
                <div className="ml-4 py-2 px-8 rounded-sm bg-black text-white">Add to Cart</div>
            </div>
        </div>
        </div>

        <div className="mt-20 mb-8 font-bold">Review</div>
        <div className="flex">
            <div className="w-[250px] rounded-sm border m-2 p-2">
                <div>
                    <img className="w-10 h-10 rounded-full border-red-400 border mr-2" />

                    <div className="text-[12px] font-bold">name</div>
                </div>
                <div className="text-[13px] mt-2 text-[gray]">
                    Lorem, ipsum dolor sit amet consectetur adipisicing elit. Illo obcaecati laboriosam totam iure dolore maiores?
                </div>
            </div>
        </div>      
    </div>
  )
}

export default SingleDetail
