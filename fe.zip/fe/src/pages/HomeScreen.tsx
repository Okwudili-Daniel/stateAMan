import userHook from "../hook/userHook"
import pix from "../assets/IMG_20230330_103649.jpg"

const HomeScreen = () => {
  const {data}: any = userHook()
  return (
    <div className="grid sm:grid-cols-1 md:grid-cols-2 xl:grid-cols-3 lg:grid-cols-3 grid-cols-1 gap-2">
      <div className="min-w-[200px] min-h-[300px] flex flex-col rounded-md shadow-md ">
        <img src={pix} className="object-cover w-full h-[250px] rounded-md " />
          <div className="mt-8">
            <div className="flex justify-between w-full">
              <div className="font-bold text-[20px]">Title  </div>
              <div className="flex items-center relative w-[200px]">
              <div className="mr-2 absolute">{"🟣".repeat(5)}</div>
              <div className="mr-2 absolute">{"⭐".repeat(4)}</div>
              {/* <div>2</div> */}
            </div>
              <div>
            </div>
          </div>
          </div>

            <div>
            
            </div>
            <div>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas, odio reprehenderit nam aspernatur ab provident? Repellendus similique iusto commodi aut?
            </div>
            <div className="flex justify-between mt-8 items-center">
              <div className="font-bold text-[28px]">₦5000</div>
              <div className="bg-purple-500 text-white px-4 py-2 rounded-sm cursor-pointer">Add to Cart</div>
            </div>
            </div>
          </div>

      // </div>
  )
}

export default HomeScreen
